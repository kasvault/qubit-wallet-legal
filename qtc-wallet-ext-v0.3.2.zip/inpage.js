// QTC Wallet inpage provider (MAIN world): window.qtc API, Kasware-ähnlich.
// Signing happens ONLY in the extension service worker — keys bleiben in der Extension.
(() => {
  let seq = 0;
  const pending = new Map();
  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (!d || d.source !== 'qtc-bridge' || !d.id) return;
    const p = pending.get(d.id);
    if (!p) return;
    pending.delete(d.id);
    d.result && d.result.ok ? p.resolve(d.result) : p.reject(new Error((d.result && d.result.error) || 'qtc: call failed'));
  });
  const call = (method, params) => new Promise((resolve, reject) => {
    const id = 'qtc-' + (++seq);
    pending.set(id, { resolve, reject });
    window.postMessage({ source: 'qtc-inpage', id, method, params }, window.location.origin);
    setTimeout(() => { if (pending.has(id)) { pending.delete(id); reject(new Error('qtc: timeout (extension nicht installiert/aktiv?)')); } }, 15000);
  });

  window.qtc = {
    isConnected: () => call('isConnected').then(r => !!r.data),
    requestAccounts: () => call('requestAccounts').then(r => r.data),
    getPublicKey: () => call('getPublicKey').then(r => r.data),
    getBalance: () => call('getBalance').then(r => r.data),
    // Desk-Funding/Claim: { tx: txJson, inputs: [{index, amountSat, type:'p2wpkh'|'p2wsh', redeemScriptHex?, preimageHex?}] }
    // v0.2.4: volles Result ({ok, data:{raw,txid}}) durchreichen — die Desk-Seite prueft r.ok/r.data.raw
    signTransaction: (req) => call('signTransaction', req),
    broadcast: (raw) => call('broadcast', { raw }).then(r => r.data),
  };
  window.dispatchEvent(new Event('qtc#initialized'));
})();
