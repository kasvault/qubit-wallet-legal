// Qubit Wallet — Approval window, v0.3.2.
// Zeigt die ECHTE Zieladresse (bech32/base58) statt eines Hex-Slices.
const $ = (s) => document.querySelector(s);
const id = location.hash.slice(1);
const send = (method, params) => chrome.runtime.sendMessage({ method, params });
const sat = (v) => (Number(v) / 1e8).toFixed(8) + ' QTC';
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

(async () => {
  const r = await send('getApproval', { id });
  const d = r && r.data;
  if (!r || !r.ok || !d) {
    $('#content').innerHTML = '<div class="err">Request no longer available (timeout or already answered).</div>';
    $('#btn-yes').style.display = 'none';
    $('#btn-no').textContent = 'Close';
    return;
  }
  $('#origin').textContent = d.origin;

  if (d.kind === 'connect') {
    $('#content').innerHTML = '<div class="box"><b>This site wants to connect</b><br><br>' + esc(d.meta.note) +
      '</div><div class="warn">You can revoke this any time in the wallet: Connected sites.</div>';
    return;
  }

  const outs = (d.meta.outputs || []).map((o) => {
    const warnType = (o.type !== 'P2WPKH');
    return '<div class="out">' +
      '<div class="amt">' + sat(o.valueSat) + '<span class="badge' + (warnType ? ' warnb' : '') + '">' + esc(o.type) + '</span></div>' +
      '<div class="dest">' + esc(o.address) + '</div>' +
      '</div>';
  }).join('');

  const hidden = d.meta.outputsHidden ? '<div class="warn">' + d.meta.outputs.length + ' outputs — scroll the list and check every destination.</div>' : '';
  const unverified = Number(d.meta.unverifiedInSat || 0) > 0
    ? '<div class="warn">' + sat(d.meta.unverifiedInSat) + ' of the inputs are contract spends (P2WSH). Their amount comes from the website and cannot be verified here.</div>'
    : '';
  const nonstd = (d.meta.outputs || []).some((o) => o.type !== 'P2WPKH')
    ? '<div class="warn">At least one destination is not a standard wallet address.</div>'
    : '';

  $('#content').innerHTML =
    '<div class="box"><b>Sign transaction</b>' +
      '<div class="kv"><span>Inputs (verified)</span><span>' + sat(d.meta.inSumSat - Number(d.meta.unverifiedInSat || 0)) + '</span></div>' +
      '<div class="kv"><span>Fee</span><span>' + sat(d.meta.feeSat) + '</span></div>' +
      '<div class="kv"><span>Signing with</span><span>' + d.meta.signedInputCount + ' / ' + d.meta.inputCount + ' inputs</span></div>' +
      '<div style="margin-top:9px;font-size:10px;letter-spacing:1.6px;text-transform:uppercase;color:#86a396">To</div>' +
      '<div class="scrollbox">' + outs + '</div>' +
    '</div>' +
    hidden + nonstd + unverified +
    '<div class="warn">Check the destination address. Approving signs with your key. Nothing is broadcast automatically.</div>';
})();

$('#btn-yes').onclick = async () => {
  const r = await send('respondApproval', { id, approved: true });
  if (r && r.ok) window.close();
  else $('#err').textContent = (r && r.error) || 'Fehler';
};
$('#btn-no').onclick = async () => {
  await send('respondApproval', { id, approved: false });
  window.close();
};
