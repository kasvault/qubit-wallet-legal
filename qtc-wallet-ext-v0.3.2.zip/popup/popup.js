// Qubit Wallet popup v0.2.9 — Passwort-Flows (create/import/unlock), Session-Lock, Legacy-Migration.
// Design v0.2.9: Matrix-Tunnel-Hintergrund, grosser Balance-Block, PubKey nur noch hinter "Show public key".
const $ = (s) => document.querySelector(s);
const send = (method, params) => chrome.runtime.sendMessage({ method, params });
const COIN = 1e8;
const VIEWS = ['view-none', 'view-seed', 'view-legacy', 'view-locked', 'view-main', 'view-backup', 'view-send', 'view-txs', 'view-sites'];
const show = (id) => { for (const v of VIEWS) $('#' + v).classList.add('hide'); $('#' + id).classList.remove('hide'); };

let fullPubkey = '';
let toastTimer = null;

// Fehler/Erfolg sind jetzt in JEDER View sichtbar (vorher lag #err unsichtbar in der Main-View).
function notify(msg, ok) {
  const t = $('#toast');
  if (!msg) { t.classList.add('hide'); return; }
  t.textContent = msg;
  t.classList.toggle('ok', !!ok);
  t.classList.remove('hide');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hide'), ok ? 2600 : 6000);
}
const err = (m) => notify(m || '', false);

function fmtQtc(sat) {
  if (sat === null || sat === undefined) return '—';
  const v = sat / COIN;
  return v >= 1 ? v.toFixed(6) : v.toFixed(8);
}

async function refresh() {
  const r = await send('walletState');
  const d = r && r.data;
  if (!d) { show('view-none'); return; }
  if (d.legacy) { show('view-legacy'); return; }
  $('#lockbadge').classList.toggle('hide', !d.locked);
  if (d.locked) {
    show('view-locked');
    $('#locked-addr').textContent = (d.address || '').slice(0, 14) + '…' + (d.address || '').slice(-6);
    $('#pass-unlock').value = '';
    return;
  }
  show('view-main');
  $('#addr').textContent = d.address;
  if (d.addrCount > 1) $('#addr').textContent = d.address + '  (' + (Number(d.addrIndex) + 1) + '/' + d.addrCount + ')';
  $('#bal').textContent = '…';

  const bal = await send('getBalance');
  $('#bal').textContent = bal && bal.data ? fmtQtc(bal.data.balanceSat) : '—';

  const pub = await send('getPublicKey');
  if (pub && pub.data) {
    fullPubkey = pub.data;
    $('#pubkey').textContent = fullPubkey;
    $('#btn-pk').classList.remove('hide');
  } else {
    fullPubkey = '';
    $('#btn-pk').classList.add('hide');
    $('#pkbox').classList.add('hide');
  }
}

// ---- Adresse kopieren (v0.2.9) ----
$('#btn-copy').onclick = async () => {
  const addr = $('#addr').textContent.trim();
  if (!addr) return;
  try {
    await navigator.clipboard.writeText(addr);
    notify('Address copied.', true);
  } catch (e) {
    try {
      const r = document.createRange();
      r.selectNodeContents($('#addr'));
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      document.execCommand('copy');
      notify('Address copied.', true);
    } catch (e2) {
      notify('Copy failed — select the address manually.', false);
    }
  }
};

// ---- PubKey ein-/ausklappen (v0.2.9) ----
$('#btn-pk').onclick = () => {
  const box = $('#pkbox');
  const hidden = box.classList.toggle('hide');
  $('#btn-pk').textContent = hidden ? 'Show public key' : 'Hide public key';
};

$('#btn-create').onclick = async () => {
  notify('');
  const r = await send('createWallet', { password: $('#pass-new').value });
  if (!r || !r.ok) { err((r && r.error) || 'Could not create wallet'); return; }
  $('#pass-new').value = '';
  $('#seed-out').textContent = r.data.mnemonic;
  show('view-seed');
};
$('#btn-seed-done').onclick = async () => { notify(''); await refresh(); };

$('#btn-import').onclick = () => $('#import-box').classList.toggle('hide');
$('#btn-do-import').onclick = async () => {
  notify('');
  const r = await send('importWallet', { mnemonic: $('#mnemonic').value, password: $('#pass-imp').value });
  if (!r || !r.ok) { err((r && r.error) || 'Import failed'); return; }
  $('#mnemonic').value = ''; $('#pass-imp').value = '';
  await refresh();
};

$('#btn-migrate').onclick = async () => {
  notify('');
  const r = await send('migrateLegacy', { password: $('#pass-mig').value });
  if (!r || !r.ok) { err((r && r.error) || 'Migration failed'); return; }
  $('#pass-mig').value = '';
  await refresh();
};

$('#btn-unlock').onclick = async () => {
  notify('');
  const r = await send('unlockWallet', { password: $('#pass-unlock').value });
  if (!r || !r.ok) { err((r && r.error) || 'Wrong password'); return; }
  $('#pass-unlock').value = '';
  await refresh();
};

$('#btn-lock').onclick = async () => {
  await send('lockWallet');
  notify('');
  await refresh();
};

// ---- Sicherheits-Backup (v0.3.0) ----
$('#btn-backup').onclick = () => {
  notify('');
  $('#pass-backup').value = '';
  $('#backup-seed').textContent = '';
  $('#backup-seed-box').classList.add('hide');
  show('view-backup');
};
$('#btn-backup-back').onclick = () => {
  notify('');
  $('#pass-backup').value = '';
  $('#backup-seed').textContent = '';
  $('#backup-seed-box').classList.add('hide');
  refresh();
};

$('#btn-backup-show').onclick = async () => {
  notify('');
  $('#backup-seed-box').classList.add('hide');
  const pass = $('#pass-backup').value;
  if (!pass) { err('Enter your wallet password'); return; }
  const r = await send('revealSeed', { password: pass });
  if (!r || !r.ok) { err((r && r.error) || 'Could not unlock the seed'); return; }
  $('#backup-seed').textContent = r.data.mnemonic;
  $('#backup-words').textContent = String(r.data.words || r.data.mnemonic.split(/\s+/).length);
  $('#backup-seed-box').classList.remove('hide');
  notify('Recovery phrase shown. Keep it offline.', true);
};

$('#btn-backup-dl').onclick = async () => {
  notify('');
  const pass = $('#pass-backup').value;
  if (!pass) { err('Enter your wallet password'); return; }
  const btn = $('#btn-backup-dl');
  btn.disabled = true;
  const r = await send('exportBackup', { password: pass });
  btn.disabled = false;
  if (!r || !r.ok) { err((r && r.error) || 'Backup failed'); return; }
  const stamp = new Date().toISOString().slice(0, 10);
  const name = 'qubit-wallet-backup-' + String(r.data.address || '').slice(0, 8) + '-' + stamp + '.json';
  try {
    const url = URL.createObjectURL(new Blob([r.data.json], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    notify('Backup saved: ' + name, true);
  } catch (e) {
    err('Download blocked by the browser — try again from the extension popup');
  }
};

$('#btn-restore').onclick = () => $('#restore-box').classList.toggle('hide');
$('#btn-do-restore').onclick = async () => {
  notify('');
  const file = $('#restore-file').files && $('#restore-file').files[0];
  const pass = $('#pass-restore').value;
  if (!file) { err('Choose a backup file (.json)'); return; }
  if (!pass) { err('Enter the password of this backup'); return; }
  let text = '';
  try { text = await file.text(); } catch (e) { err('Could not read the file'); return; }
  const r = await send('importBackup', { json: text, password: pass });
  if (!r || !r.ok) { err((r && r.error) || 'Restore failed'); return; }
  $('#restore-file').value = '';
  $('#pass-restore').value = '';
  $('#restore-box').classList.add('hide');
  notify('Wallet restored.', true);
  await refresh();
};

// ---- Send-Flow (v0.2.6): Wallet-Popup-sends sind selbst die Autorisierung ----
$('#btn-send').onclick = () => {
  notify('');
  $('#send-ok').classList.add('hide');
  show('view-send');
};

// ---- Transactions (v0.2.7) ----
$('#btn-txs').onclick = async () => {
  notify('');
  show('view-txs');
  const list = $('#tx-list');
  list.textContent = 'Loading…';
  const r = await send('getTransactions');
  if (!r || !r.ok) { list.textContent = (r && r.error) || 'History unavailable'; return; }
  const txs = r.data.txs || [];
  if (!txs.length) { list.textContent = 'No transactions yet.'; return; }

  list.textContent = '';
  for (const t of txs) {
    const dir = t.dir === 'in' ? '↓ IN' : t.dir === 'out' ? '↑ OUT' : '↺ SELF';
    const col = t.dir === 'in' ? '#4dffa1' : t.dir === 'out' ? '#ff9b8f' : '#86a396';
    const when = t.blockTime ? new Date(t.blockTime).toLocaleString() : (t.confirmed ? '' : 'pending');
    const txidFull = String(t.txid || '').replace(/[^0-9a-f]/g, ''); // komplette TXID, hex-sauber

    const item = document.createElement('div');
    item.className = 'txitem';

    const amt = document.createElement('div');
    amt.className = 'txamt';
    amt.style.color = col;
    amt.textContent = dir + ' ' + (t.amountSat / COIN).toFixed(8) + ' QTC';
    item.appendChild(amt);

    const meta = document.createElement('div');
    meta.className = 'txmeta';
    meta.textContent = when ? when + ' · TXID' : 'TXID';
    item.appendChild(meta);

    const txid = document.createElement('div');
    txid.className = 'txtxid';
    txid.textContent = txidFull;
    item.appendChild(txid);

    list.appendChild(item);
  }
};
$('#btn-txs-back').onclick = () => { notify(''); refresh(); };
$('#btn-send-back').onclick = () => { notify(''); refresh(); };

$('#btn-send-go').onclick = async () => {
  notify('');
  $('#send-ok').classList.add('hide');
  const to = $('#send-to').value.trim();
  const amountQtc = $('#send-amt').value.trim();
  const feeQtc = $('#send-fee').value.trim();
  if (!to || !amountQtc) { err('Recipient and amount are required'); return; }
  const btn = $('#btn-send-go');
  btn.textContent = 'Sending…';
  btn.disabled = true;
  const params = { to, amountQtc };
  if (feeQtc) params.feeSat = Math.round(parseFloat(feeQtc) * 1e8);
  const r = await send('sendQtc', params);
  btn.textContent = 'Send now';
  btn.disabled = false;
  if (!r || !r.ok) { err((r && r.error) || 'Sending failed'); return; }
  $('#send-to').value = ''; $('#send-amt').value = ''; $('#send-fee').value = '';
  const ok = $('#send-ok');
  ok.textContent = '';
  ok.classList.remove('hide');
  ok.innerHTML = '<div class="panel" style="padding:10px">'
    + '<div class="eyebrow">Sent</div>'
    + '<div class="addr" style="margin-top:6px">' + String(r.data.txid) + '</div>'
    + '<div class="note" style="margin:8px 0 0">Fee: ' + (r.data.feeSat / COIN).toFixed(8) + ' QTC</div>'
    + '</div>';
  const bal = await send('getBalance');
  if (bal && bal.data) { /* Balance aktualisiert sich beim Zurueckgehen */ }
};

refresh();


// ---- Neue Adresse (v0.3.2, HD-Rotation) ----
$('#btn-new-addr').onclick = async () => {
  notify('');
  const btn = $('#btn-new-addr');
  btn.disabled = true;
  const r = await send('newAddress');
  btn.disabled = false;
  if (!r || !r.ok) { err((r && r.error) || 'Could not create a new address'); return; }
  notify('New address created (# ' + (r.data.index + 1) + ')', true);
  await refresh();
};

// ---- Verbundene Seiten (v0.3.2) ----
async function loadSites() {
  const list = $('#site-list');
  list.textContent = 'Loading…';
  const r = await send('listOrigins');
  if (!r || !r.ok) { list.textContent = (r && r.error) || 'Unavailable'; return; }
  const origins = r.data || [];
  if (!origins.length) { list.textContent = 'No site is connected.'; return; }
  list.textContent = '';
  for (const o of origins) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid rgba(0,255,122,0.12)';
    const name = document.createElement('span');
    name.textContent = o;
    name.style.cssText = 'flex:1;word-break:break-all;color:#9dffcb';
    const b = document.createElement('button');
    b.className = 'mini';
    b.textContent = 'Revoke';
    b.onclick = async () => {
      const rr = await send('revokeOrigin', { origin: o });
      if (!rr || !rr.ok) { err((rr && rr.error) || 'Revoke failed'); return; }
      notify('Revoked ' + o, true);
      loadSites();
    };
    row.appendChild(name); row.appendChild(b);
    list.appendChild(row);
  }
}

$('#btn-sites').onclick = () => { notify(''); show('view-sites'); loadSites(); };
$('#btn-sites-back').onclick = () => { notify(''); refresh(); };
$('#btn-sites-revoke-all').onclick = async () => {
  const r = await send('revokeAllOrigins');
  if (!r || !r.ok) { err((r && r.error) || 'Revoke failed'); return; }
  notify('All sites disconnected', true);
  loadSites();
};
