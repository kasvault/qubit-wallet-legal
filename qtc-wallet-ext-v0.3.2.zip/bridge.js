// QTC Wallet content bridge (ISOLATED world): relays window.qtc calls <-> service worker.
// v0.2.6: WHITELIST — nur die oeffentlichen window.qtc-Methoden duerfen passieren.
// Wallet-Management (create/import/unlock/sendQtc/...) bleibt IM Extension-Kontext.
const BRIDGE_ALLOW = ['isConnected', 'requestAccounts', 'getPublicKey', 'getBalance', 'signTransaction', 'broadcast'];
window.addEventListener('message', async (ev) => {
  const d = ev.data;
  if (!d || d.source !== 'qtc-inpage' || !d.id) return;
  const reply = (result) => window.postMessage({ source: 'qtc-bridge', id: d.id, result }, ev.origin);
  if (!BRIDGE_ALLOW.includes(d.method)) {
    reply({ ok: false, error: 'qtc: Methode nicht erlaubt (' + d.method + ')' });
    return;
  }
  try {
    const res = await chrome.runtime.sendMessage({ id: d.id, method: d.method, params: d.params || {} });
    reply(res && res.ok !== undefined ? res : { ok: true, data: res });
  } catch (e) {
    reply({ ok: false, error: String(e && e.message || e) });
  }
});
